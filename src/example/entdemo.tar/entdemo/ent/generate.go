package ent

//go:generate go run entgo.io/ent/cmd/ent generate ./schema
